import { render, screen, fireEvent } from '@testing-library/react';
import Button from './Button';

test('affiche le texte du bouton', () => {
  render(<Button label="Cliquez-moi" />);
  expect(screen.getByText('Cliquez-moi')).toBeInTheDocument();
});

test('déclenche onClick quand on clique', () => {
  const handleClick = jest.fn();
  render(<Button label="Cliquez-moi" onClick={handleClick} />);
  fireEvent.click(screen.getByText('Cliquez-moi'));
  expect(handleClick).toHaveBeenCalledTimes(1);
});
