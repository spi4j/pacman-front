import React from 'react';
import AppRoutes from './routes/AppRoutes';

export default function App() {
  return (
    <div>
      <h1>Mon projet Vite React TypeScript</h1>
      <AppRoutes />
    </div>
  );
}

