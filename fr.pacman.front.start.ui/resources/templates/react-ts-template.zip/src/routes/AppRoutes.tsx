import React from 'react';
import Home from '../pages/Home';

export default function AppRoutes() {
  // Ici tu peux utiliser React Router si besoin
  return <Home />;
}
