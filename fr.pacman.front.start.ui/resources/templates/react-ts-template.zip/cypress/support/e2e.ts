// Import commands.ts pour les commandes personnalisées
import './commands';

// Optionnel : configuration avant chaque test
beforeEach(() => {
  // par ex. reset de la base de données ou réinitialisation de l'état
});
