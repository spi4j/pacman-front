import { defineConfig } from 'cypress';

export default defineConfig({
  e2e: {
    baseUrl: 'http://localhost:5173', // URL de ton app Vite
    supportFile: 'cypress/support/e2e.ts',
    specPattern: 'cypress/e2e/**/*.ts',
    video: false,
    screenshotOnRunFailure: true,
  },
  env: {
    apiUrl: 'http://localhost:3000/api' // exemple si tu testes des API
  },
});
