export default {
  "data-fr-assets-path": "/dsfr",
};