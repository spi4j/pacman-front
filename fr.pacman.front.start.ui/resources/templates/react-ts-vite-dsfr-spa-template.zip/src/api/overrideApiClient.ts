//import { apiClient as frontApiClient } from "./apiClient";       
//import { apiClient as libApiClient } from "demo-dsfr-client-rest"; 

// On remplace toutes les propriétés de l'instance de la librairie par celles du front
//Object.assign(libApiClient, frontApiClient);