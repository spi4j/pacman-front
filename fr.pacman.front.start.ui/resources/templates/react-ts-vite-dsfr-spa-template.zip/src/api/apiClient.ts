import axios, { AxiosInstance, AxiosRequestConfig } from "axios";
import { apiConfig } from "./apiConfig";

// Construction de la configuration finale
const finalConfig: AxiosRequestConfig = {
  ...apiConfig,
  timeout: apiConfig.timeout ?? 15000,
};

// Création de l’instance axios
const apiClient: AxiosInstance = axios.create(finalConfig);

// Interceptor Request
apiClient.interceptors.request.use(
  (config) => {
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor Response
apiClient.interceptors.response.use(
  (response) => response,
  (error) => Promise.reject(error)
);

export { apiClient };