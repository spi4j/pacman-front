import axios from "axios";

export const apiConfig = {    
   baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:8081",
   headers: {
     "Content-Type": "application/json",
   },
   timeout: 15000,
};