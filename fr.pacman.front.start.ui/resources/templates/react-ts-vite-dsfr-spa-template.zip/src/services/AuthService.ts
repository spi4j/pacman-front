
export type User = {
  id: string;
  username: string;
  roles: string[]; // ex: ['USER'], ['ADMIN']
  displayName?: string;
};

const mockUsers: User[] = [
  { id: "1", username: "12345", roles: ["USER"], displayName: "John Doe" },
  { id: "2", username: "admin", roles: ["ADMIN", "USER"], displayName: "Admin" },
  // tu peux ajouter d'autres comptes de test ici, ex: { username: "test", password: "test" } (password not stored here)
];

// Pour simplifier, on accepte un couple username/password en clair (fake)
export async function login(username: string, password: string): Promise<User | null> {
  // Simule délai réseau
  await new Promise((r) => setTimeout(r, 200));
  // règle simple : "12345"/"azerty" ou "admin"/"admin"
  if ((username === "12345" && password === "azerty") || (username === "admin" && password === "admin")) {
    return mockUsers.find((u) => u.username === username) ?? null;
  }
  return null;
}

export async function logout(): Promise<void> {
  await new Promise((r) => setTimeout(r, 50));
  return;
}
