import React, { StrictMode } from "react";
import ReactDOM from "react-dom/client";
import App from './App.tsx'

import { startReactDsfr } from "@codegouvfr/react-dsfr/spa";
import "@gouvfr/dsfr/dist/dsfr.min.css";
import "@gouvfr/dsfr/dist/utility/utility.min.css";
import "@gouvfr/dsfr/dist/utility/icons/icons.min.css";

// Initialisation DSFR
startReactDsfr({
  defaultColorScheme: "system",
  defaultLanguage: "fr"
});

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
