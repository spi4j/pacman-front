import { useState } from 'react'
import { Button } from "@codegouvfr/react-dsfr/Button";

import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",   // centre horizontal
        justifyContent: "center", // centre vertical
        minHeight: "100vh",     // occupe toute la hauteur
        textAlign: "center",    // texte centré
        gap: "1rem"
      }}
    >
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>

      <h1>Vite + React + Dsfr (spa)</h1>

      <div className="card">
        <Button 
          iconId="fr-icon-checkbox-circle-line" 
          onClick={() => setCount((count) => count + 1)}
          style={{ marginBottom: "2rem" }}
        >
          count is {count}
        </Button>

        <p>
          Editez <code>src/App.tsx</code> et sauvegardez pour le remplacement à chaud des modules
        </p>
      </div>

      <p className="read-the-docs">
        Cliquez sur les logos Vite et React pour plus de détails
      </p>
    </div>
  )
}

export default App
